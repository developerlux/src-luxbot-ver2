const Discord = require("discord.js");

exports.run = async (client, message, args) => {

const ayarlar = require('../ayarlar.json');
var room = ayarlar.commandroom;

if (message.channel.id != room) {
	return;
  }

// Example command
if(!args[0]) {
	const embed1 = new Discord.MessageEmbed()
	.setColor('RANDOM')
	.setTitle('`          🚥! 𝐌𝐄𝐓𝐇𝐎𝐃𝐒 !🚥`')
	.setDescription("**Layer 7 By LUX BOT 💠** \n `  BYPASS` \n `  CF-SK` \n `  CF-TLS` \n `  CFB` \n `  SOCKET + <time>` \n `  LUX    + <time>` \n `  CF-V2  + <time>` \n `  CFL-V1  + <time>` \n `  HTTP-RAW  + <time>` \n `  HTTP-RX  + <time>` \n `  HTTP-RAN  + <time>` \n `  BROWSER  + <time>` \n `  CFB-BYPASS  + <time>` \n `  CFM-BYPASS  + <time>` \n **Layer 4 By LUX BOT 💠** \n `  👻 Chờ Update Thêm Đi Mấy Em 👻` \n **stop <Dừng all lệnh>** \n **thongbao <Xem Thông Báo And Nội Quy BOT>**")
	.setFooter('© Developer: Phuc#2005', client.user.avatarURL)
	message.channel.send(embed1);
	return;
	}

}

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['methods'],
  permLevel: 0
}

exports.help = {
  name: 'methods',
  description: 'Phuc',
  usage: 'methods'
}
